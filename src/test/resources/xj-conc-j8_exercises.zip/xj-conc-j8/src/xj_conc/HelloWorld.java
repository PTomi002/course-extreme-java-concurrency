package xj_conc;

import org.junit.*;

public class HelloWorld {
    @Test
    public void testSetup() {
        System.out.println("Hello World!");
    }
}
