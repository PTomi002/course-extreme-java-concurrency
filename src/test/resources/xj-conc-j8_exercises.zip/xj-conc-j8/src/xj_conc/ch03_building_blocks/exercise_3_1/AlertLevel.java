package xj_conc.ch03_building_blocks.exercise_3_1;

/**
 * DO NOT CHANGE.
 */
public enum AlertLevel {
    GREEN, ORANGE, RED
}
