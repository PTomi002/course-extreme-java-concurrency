package xj_conc.ch03_building_blocks.exercise_3_2;

/**
 * DO NOT CHANGE.
 */
public enum Priority {
    HIGH, NORMAL, LOW
}
