package xj_conc.ch08_avoiding_liveness_hazards.exercise_8_1;

public enum ThinkerStatus {
    HAPPY_THINKER, UNHAPPY_THINKER
}
