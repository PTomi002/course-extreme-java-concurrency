package xj_conc.ch04_task_execution.exercise_4_1;

public interface Constants {
    int NUMBERS_TO_CHECK = 20_000;
    long START = (1 << 19) - 1;
}